import boto3
import json
import os
import urllib.request

def handler(event, context):
    secret_name = os.environ['GITHUB_SECRET_NAME']
    repo = os.environ['GITHUB_REPO']
    workflow = os.environ['GITHUB_WORKFLOW']

    sm = boto3.client('secretsmanager', region_name=os.environ['AWS_REGION'])
    secret = json.loads(sm.get_secret_value(SecretId=secret_name)['SecretString'])
    token = secret['token']

    url = f'https://api.github.com/repos/{repo}/actions/workflows/{workflow}/dispatches'
    payload = json.dumps({'ref': 'main'}).encode()

    req = urllib.request.Request(url, data=payload, method='POST')
    req.add_header('Authorization', f'token {token}')
    req.add_header('Accept', 'application/vnd.github.v3+json')
    req.add_header('Content-Type', 'application/json')

    with urllib.request.urlopen(req) as response:
        print(f'GitHub API response: {response.status}')

    return {'statusCode': 200}
